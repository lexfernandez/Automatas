package automata

/**
 * Created by lex on 09-08-16.
 */
class Production(var noTerminal:Char,var production:String)