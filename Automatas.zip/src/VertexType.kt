enum class VertexType {
    NORMAL, INITIAL, FINAL, INITIAL_FINAL
}